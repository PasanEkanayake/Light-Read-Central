{{ ucfunc("put_docready_start") }}

  var objList = jQuery("#{{uc_id}}");

  {% if directional_hover == "true" %}
  
  	var objItem = objList.find(".ue-item");
   
  	objItem.directionalHover();
   
    objList.on("uc_ajax_refreshed",function(){
      
     	objItem = objList.find(".ue-item");
   
  		objItem.directionalHover();   
      
  	});
  
  {% endif %}

  {% if remote_parent.attributes is not empty %}

     var objRemoteOptions = {
          class_items:"ue-item",
          class_active:"ue-active-item",
          add_set_active_code:true
      };

      {{ucfunc("put_remote_parent_js","objList","objRemoteOptions")}}  

  {% endif %}

{{ ucfunc("put_docready_end") }}