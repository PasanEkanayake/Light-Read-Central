#{{uc_id}} {
  display:flex;
  align-items: center;
}

#{{uc_id}} .ca_btn_container{
  position: relative;
  display: inline-block;
}

#{{uc_id}} .ca_btn {
  display:inline-flex;
  align-items: center;
  box-sizing: border-box;
  overflow: hidden;
  cursor: pointer;
}

#{{uc_id}} .ca_btn .ca_dropdown {
  width:100%;
  margin: 0;
  padding: 0;
  transform: translate(-50%, 25px);
  position: absolute;
  top: 100%;
  left:50%;
  text-align: left;
  opacity: 0;
  visibility: hidden;
  z-index:9999;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

#{{uc_id}} .ca_btn.ue_active_drop .ca_dropdown {
  left:50%;
  transform: translate(-50%, {{dropdown_gap_nounit}}px);
  opacity: 1;
  visibility: visible;
  transition-delay: 0ms;
}

{% if keep_dropdown_active == "ca_active" %}
  #{{uc_id}} .ca_dropdown.ca_active{
    left:50%;
    transform: translate(-50%, {{dropdown_gap_nounit}}px);
    opacity: 1;
    visibility: visible;
    transition-delay: 0ms;
  }
{% endif %}

#{{uc_id}} .ca_btn .ca_dropdown li {
  z-index: 1;
  position: relative;
  margin: 0;
  list-style: none;
  margin: 0;
  display: inline;
}

#{{uc_id}} .ca_btn .ca_dropdown li:last-child a {
  border-bottom: 0;
}

#{{uc_id}} .ca_btn .ca_dropdown a {
  transition:300ms;
  display: flex;
  align-content: center;
  align-items: center;
  border-bottom-style: solid;
  white-space: pre-line;
  text-decoration: none;
}

#{{uc_id}} .ca_dropdown i{
  transition:300ms;
}

@media only screen and (max-width: 767px) {...}