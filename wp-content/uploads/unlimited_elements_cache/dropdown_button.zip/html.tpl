<div id="{{uc_id}}" class="ca_btn_wrapper {{uc_filtering_addclass}}" {{uc_filtering_attributes|raw}}>
  <div class="ca_btn_container">
    <button class="ca_btn" >{% if show_btn_icon == "true" %}{{btn_icon_html|raw}}{% endif %}<span class="ue-btn-text">{{button_text|raw}}</span>
      <ul class="ca_dropdown uc-items-wrapper {{keep_dropdown_active}}">
         {{put_items()}}
      </ul>
    </button>
  </div>
</div>