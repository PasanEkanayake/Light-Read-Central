{{ ucfunc("put_docready_start") }}
	var objWidget = jQuery("#{{uc_id}}");
	var objItemLinks = objWidget.find(".ca_dropdown_item a");
	var objButton = objWidget.find(".ca_btn");
	var objButtonText = objWidget.find(".ue-btn-text");
	var classActive = "ue_active_drop";
	var isMouseEntered = false;

   {% if change_button_text_to_selected_item == "true" %}	
   
     objItemLinks.on('click', function(){
      var newText = jQuery(this).text();
       
      objButtonText.text(newText);
     });
    
   {% endif %}	
   
   /**
   * set active
   */
   function setActive(){
     objButton.addClass(classActive);
   }
    
   /**
   * set disactive
   */ 
   function setDisActive(){
     objButton.removeClass(classActive);
   } 
   
   /**
   * toggle active
   */ 
   function toggleActive(){
      var isActive = objButton.hasClass(classActive);
      
      if(isActive == true)
      setDisActive();
      else
      setActive();
   }
   
   {% if hide_dropdown_after_selection == "true" %}
     objButton.on('click', function(){
       
       if(isMouseEntered == false)
         toggleActive();
     });
   {% endif %} 
   
   objButton.on('mouseenter', function(){
     setActive();
     
     isMouseEntered = true;
     
     //set small timeout to avoid instant click event after mouse enter on mobile
     setTimeout(function(){
       isMouseEntered = false;
     },100);
   });
    
   objButton.on('mouseleave', function(){
   	 setDisActive();     
   });
  
{{ ucfunc("put_docready_end") }}