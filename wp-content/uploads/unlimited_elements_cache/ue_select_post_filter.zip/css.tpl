#{{uc_id}}.uc-filter-hidden,
#{{uc_id}}.uc-filter-initing.uc-initing-filter-hidden{
  display:none !important;
}

#{{uc_id}} .uc-filter-item-hidden{
	display:none;
}

#{{uc_id}} .uc-select-filter__loader{
	position:absolute;
  	top:0px;
    width:100%;
    height:100%;
  	background-color:lightgray;
}

#{{uc_id}}.uc-filter-initing .uc-select-filter__loader{	
  display:block !important;
}

#{{uc_id}}.uc-filter-initing{
  opacity:1 !important;
}

#{{uc_id}} label{
  flex-shrink:1;
  display:block;
}

#{{uc_id}}{
  align-items:center;
}

#{{uc_id}} select{
	-webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
}

#{{uc_id}} .uc-select-filter__select-wrapper{
	position: relative;
}

#{{uc_id}} .uc-select-filter__select-indicator{
	position: absolute;
  	top: 50%;
  	transform: translate(0, -50%);
  	z-index: 1;
  	height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  	pointer-events: none;
}