{{ ucfunc("put_docready_start") }}

  jQuery("#{{uc_id}}-toggle").click(function(){
    
    jQuery("#{{uc_id}}-container").toggle();
    jQuery("#{{uc_id}}-toggle .ue_taxonomy_toggle_icon_open").toggle();
    jQuery("#{{uc_id}}-toggle .ue_taxonomy_toggle_icon_close").toggle();
  });
    	
{{ ucfunc("put_docready_end") }}