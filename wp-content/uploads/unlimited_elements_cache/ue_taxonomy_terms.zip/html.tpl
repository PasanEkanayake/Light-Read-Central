<div class="ue_taxonomy_toggle" id="{{uc_id}}-toggle">
  <div class="ue_taxonomy_toggle_icon">
    <div class="ue_taxonomy_toggle_icon_open">{{open_toggle_icon_html|raw}}</div>
    <div class="ue_taxonomy_toggle_icon_close">{{close_toggle_icon_html|raw}}</div>
  </div>
</div>

<div id="{{uc_id}}-container">
 
<div id="{{uc_id}}" class="ue_taxonomy">
  {% for term in taxonomy %}
  <a {% if disable_term_link == "false" %}href="{{term.link}}"{% endif %} class="ue_taxonomy_item {{term.class_selected}} {{term.class_add_parent}} {{term.class_add_level}}">
    
    
    {% if show_image == "true" %}
    	{% set image = ucfunc("get_term_image",term.id,image_meta_field) %}
    	
    	{% if debug_meta == "true" %}
    		{{printVar(image)}}
    	{% endif %}
    	
    	{% if image is not empty %}
    		
         <div class="ue_taxonomy_image"><img class="uc-term-image" src="{{image.thumb_large}}" alt="{{image.title}}" ></div>
    		
    	{% endif %}
    {% endif %}
    
    
    <div class="ue_taxonomy_item_content">
      {% if show_icon == "true" %}
        <span class="ue_taxonomy_item_icon"><i class="{{icon}}"></i></span>
        <span class="ue_taxonomy_item_icon_spacer"></span>
      {% endif %}
      <span  class="ue_taxonomy_item_title">{{term.name|raw}}</span>
      {% if show_number_of_posts == "true" %}
         <span class="ue_taxonomy_item_num_posts_spacer"></span>
         <span class="ue_taxonomy_item_num_posts">{{term.num_posts}}</span>
      {% endif %}
    </div>
      {% if show_description == "true" %}<div class="ue_taxonomy_item_description">{{term.description}}</div>{% endif %}
    
    
        
  </a>
  
    {% if debug_meta == "true" %}
    
      {% set arrMeta = getTermMeta(term.id) %}
      {{printVar(arrMeta)}}
    
    {% endif %}
  
  {% endfor %}
  
</div>
</div>