#{{uc_id}} .ue_taxonomy_item_content{
  display:flex;
  align-items:center;
}

#{{uc_id}} .ue_taxonomy_image img{
  width:100%;
  display:block;
}

#{{uc_id}} .ue_taxonomy_item_icon{
  flex-grow:0;
  flex-shrink:0;
}

#{{uc_id}} .ue_taxonomy_item_icon_spacer{
  flex-grow:0;
  flex-shrink:0;
}

#{{uc_id}} .ue_taxonomy_item_num_posts{
  flex-grow:0;
  flex-shrink:0;
}

#{{uc_id}} .ue_taxonomy_item_title{
  flex-grow:1;
}

#{{uc_id}} .ue_taxonomy_item_num_posts_spacer{
  flex-grow:0;
  flex-shrink:0;
}

#{{uc_id}}-toggle{
  display:none;
}

#{{uc_id}}-toggle .#{{uc_id}}-toggle{
  display:none;
}

#{{uc_id}}-toggle .ue_taxonomy_toggle_icon{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  line-height:1em;
  cursor:pointer;
}

#{{uc_id}}-toggle .ue_taxonomy_toggle_icon svg{
  height:1em;
  width:1em;
}

#{{uc_id}}-toggle .ue_taxonomy_toggle_icon_close{
  display:none;
}

{% if item_type == "grid" %}
  #{{uc_id}}-container .ue_taxonomy{
    display:grid;
  }

  #{{uc_id}}-container .ue_taxonomy_item{
    display:block;
  }
{% endif %}


{% if item_type == "inline" %}
  #{{uc_id}}-container .ue_taxonomy_item{
    display:inline-block;
  }
{% endif %}


@media only screen and (max-width: {{responsive_breakpoint}}px) {
 
  #{{uc_id}}-toggle{
    display:block;
  }

  #{{uc_id}}-container{
    display:none;
  }
  
}