#{{uc_id}}
{
  display:flex;
}

#{{uc_id}} .ue-post-pagination-btn
{
  display:flex;
  align-items:center;
  transition:0.3s;
}

#{{uc_id}} .ue-post-pagination-btn-icon
{
  line-height:1em;
}

#{{uc_id}} .ue-post-pagination-btn-icon svg
{
  height:1em;
  width:1em;
}