<div class="ue-post-navigation" id="{{uc_id}}">
{% set nextPostData = ucfunc("get_nextprev_post_data","next") %}
{% if nextPostData is empty %}
{% else %}
<a href="{{nextPostData.link}}" class="ue-post-pagination-btn">
<div class="ue-post-pagination-btn-icon">
  {{prev_icon_html|raw}}
</div>
<div class="ue-post-pagination-btn-label">

    {% if show_labels == "true" %}<div class="ue-post-pagination-btn-label-txt">{{prev_label|raw}}</div>{% endif %}
    {% if show_post_titles == "true" %}<div class="ue-post-pagination-btn-label-title">{{nextPostData.title}}</div>{% endif %}
</div>
</a>
{% endif %}



{% set nextPostData = ucfunc("get_nextprev_post_data","prev") %}
{% if nextPostData is empty %}
{% else %}
<a href="{{nextPostData.link}}" class="ue-post-pagination-btn">
<div class="ue-post-pagination-btn-label">
    {% if show_labels == "true" %}<div class="ue-post-pagination-btn-label-txt">{{next_label|raw}}</div>{% endif %}
    {% if show_post_titles == "true" %}<div class="ue-post-pagination-btn-label-title">{{nextPostData.title}}</div>{% endif %}
</div>
<div class="ue-post-pagination-btn-icon">
  {{next_icon_html|raw}}
</div>
</a>
{% endif %}
  
</div>