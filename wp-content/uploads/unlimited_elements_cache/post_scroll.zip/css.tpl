#{{uc_id}} .ue_post_scroll_item
{
  display:flex;
}

#{{uc_id}} .ue_post_image
{
  flex-shrink:0;
  flex-grow:0;
  display:flex;
}

#{{uc_id}} .ue-scroller-content
{
  flex-grow:1;
  display:flex;

}

#{{uc_id}} .ue_post_image img
{
  width:100%;
  object-fit: cover;
}

#{{uc_id}} .ue_image_spacer
{
  flex-shrink:0;
  flex-grow:0;
}

#{{uc_id}} .ue_calendar_spacer
{
  flex-shrink:0;
  flex-grow:0;
}

.ue-post-title
{
  font-size:21px;
}
.ue-post-desc
{
  font-size:14px;
}

#{{uc_id}} .ue-post-calendar
{
  text-align:center;
  display:flex;
}

#{{uc_id}} .ue-post-calendar-holder
{
  overflow:hidden;
}

.ue-calendar-date
{
  font-size:32px;
}

#{{uc_id}} .uc_more_btn{

  display:{{button_style}};
  text-align:center;
  text-decoration:none;
}

.ue-post-category
{
  font-size:12px;
}

#{{uc_id}} .bx-wrapper
{
  box-shadow:none;
  overflow:hidden;
  margin-bottom:0;
  border:none;
  background:transparent;
}

#{{uc_id}} .bx-viewport
{
  overflow:hidden;
}


#{{uc_id}} .bx-wrapper .bx-pager
{
  position:relative;
  bottom:auto;
  padding-top:{{bullet_spacing}};
}

#{{uc_id}} .bx-wrapper .bx-pager.bx-default-pager a
{
  width:{{bullet_size}};
  height:{{bullet_size}};
  border-radius:50%;
  background-color:{{bullet_background}};
}

#{{uc_id}} .bx-wrapper .bx-pager.bx-default-pager a.active
{
  background-color:{{bullet_background_active}};
}

#{{uc_id}} .bx-wrapper .bx-pager.bx-default-pager a:hover
{
  background-color:{{bullet_background_hover}};
}

#{{uc_id}} .bx-wrapper .bx-pager.bx-default-pager a.active:hover
{
  background-color:{{bullet_background_active}};
}



#{{uc_id}} .ue-calendar-month, #{{uc_id}} .ue-calendar-day
{
  display:flex;
  align-items:center;
  justify-content:center;
}

#{{uc_id}} .ue-scroller-content-container
{
  width:100%;
}

{% if collapse_on_mobile == "true" %}
	
@media only screen and (max-width: 600px) {
  #{{uc_id}} .ue_post_scroll_item
    {
      flex-direction:column;
    }
}  
{% endif %}