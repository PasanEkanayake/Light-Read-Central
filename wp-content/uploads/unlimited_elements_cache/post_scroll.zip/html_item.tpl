<div class="ue-scroller-box" id="{{item.item_id}}">
     <div class="ue_post_scroll_item" >
       	  {% if show_image == "true" %}
          <div class="ue_post_image">
            <a href="{{item.post.link}}"><img src="{% if item.post.image is empty %}{{uc_assets_url}}/no-image.png{% else %}{{item.post.image}}{% endif %}" alt="{{item.post.title}}"></a>
          </div>
          <div class="ue_image_spacer"></div>
          {% endif %}	
       
          <div class="ue-scroller-content">
            <div class="ue-scroller-content-container">
              {% if show_category == "true" %}<div class="ue-post-category"><a href="{{item.post.category_link}}">{{item.post.category_name}}</a></div>{% endif %}
              {% if show_title == "true" %}<div class="ue-post-title"><a href="{{item.post.link}}">{{item.post.title|raw}}</a></div>{% endif %}
              {% if show_date == "true" %}<div class="ue-post-date">{{item.post.date|ucdate("d F, Y")|raw}}</div>{% endif %}
              {% if show_time_ago == "true" %}<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{time_ago_icon_html|raw}}</span> {{text_before_time_ago|raw}} {{item.post.date|ucdate("time_ago")|raw}}</div>{% endif %}
              {% if show_text == "true" %}<div class="ue-post-text">{{item.post.intro_full|truncate(intro_number_of_characters)|raw}}</div>{% endif %}
              {% if show_button == "true" %}<div class="ue_post_button"><a href="{{item.post.link}}" class="uc_more_btn">{{button_text|raw}}</a></div>{% endif %}
            </div>
          </div>
       	
           {% if show_calendar == "true" %}
       	   <div class="ue_calendar_spacer"></div>
           <div class="ue-post-calendar">
             <div class="ue-post-calendar-holder">
               <div class="ue-calendar-date">{{item.post.date|ucdate("d")}}</div>
               <div class="ue-calendar-month">{{item.post.date|ucdate("M")}}</div>
             </div>
           </div>
           {% endif %}
     </div>
</div>