<div id="{{uc_id}}" class="ue-post-scroll-wrapper{{uc_filtering_addclass}}" {{uc_filtering_attributes|raw}}>
  <div class="ue-post-scroll uc-items-wrapper">
    {{put_items()}}
  </div>
</div>