{% if item.item_index > items_visible %}
  #{{item.item_id}}{
  display: none;
  }  
{% endif %}