jQuery(document).ready(function(){	
function {{uc_id}}_start(){

  	var objWrapper = jQuery('#{{uc_id}}');
  	var objSlider = objWrapper.find(".ue-post-scroll");
  	var objSliderItems = objWrapper.find(".ue-scroller-box");
  	
  	var options = {
		minSlides: {{items_visible}},
		mode: 'vertical',
        slideMargin: {{item_margin}},
		speed: {{transition_speed}},
		pager: {{bullets}},
        randomStart: {{random_start}},
		controls: false,
        autoHover: {{pause_on_hover}},
        responsive: true,
        touchEnabled: false,                                                
		auto: {{autoplay}},
		moveSlides: 1,
        pause: {{pause}},                                          
		adaptiveHeight:true
    };
  
  	objSliderItems.css({'display': 'block'})
    objSlider.bxSlider(options);
  	
  	objWrapper.on("uc_ajax_refreshed", function(){
        objSlider.destroySlider();
    	objSlider.bxSlider(options);
    });
    
}setTimeout(function(){if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});},100);
});