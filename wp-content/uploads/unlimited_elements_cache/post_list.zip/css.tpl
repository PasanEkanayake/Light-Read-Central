#{{uc_id}}{
  display:grid;
}

#{{uc_id}} .uc_post_list_image div{
  background-size:cover;
  background-position:center;
}

.uc_post_list .uc_post_list_box{
	position: relative;
	overflow: hidden;
	display: flex;
}

#{{uc_id}} .uc_post_list_image{
  flex-grow:0;
  flex-shrink:0;
  overflow: hidden;
}

#{{uc_id}} .uc_post_list_image img{
  width:100%;
  height:100%;
  display:block;
  transition:0.3s;  
}

.uc_post_list_title a{
	color: #333333;
    display: block;
}

.uc_post_list_date{
	font-size: 12px;
}

#{{uc_id}} .uc_post_list_content{
  display:flex;
  flex-direction:column;
  flex:1;
}

#{{uc_id}} .uc_more_btn{
  text-align:center;
  text-decoration:none;
  transition:0.3s;
}

#{{uc_id}} .button-on-side{
  display:flex;
  align-items:center;
}

#{{uc_id}} .ue-grid-item-category{
  display: flex;
  align-items: center;
}

.ue-grid-item-category a{
  display:inline-block;
  font-size:10px;
  text-transform:uppercase;
}

#{{uc_id}} .ue-meta-data{  
  display:flex;
  flex-wrap: wrap;
  line-height:1em;
}

#{{uc_id}} .ue-grid-item-meta-data{
      display:inline-flex;
      align-items:center;
}

.ue-grid-item-meta-data{
  font-size:12px;
}

#{{uc_id}} .ue-grid-item-meta-data-icon{
  line-height:1em;
}

#{{uc_id}} .ue-grid-item-meta-data-icon svg{
  width:1em;
  height:1em;
} 

#{{uc_id}} .ue-debug-meta{
  padding:10px;
  border:1px solid red;
  position:relative;
  line-height:1.5em;
  font-size:11px;
  width:100%;
}

.uc-remote-parent .uc_post_list_box{
	cursor:pointer;
}

#{{uc_id}} .ue-post-link-overlay{
  display:block;
  position:absolute;
  top:0;
  bottom:0;
  right:0;
  left:0;
}

{% if disable_link == "true" %}
  #{{uc_id}} a{
    text-decoration:none;
  }
{% endif %}

{% if show_tags == "true" %}
  #{{uc_id}} .ue_tags_terms{
    display: flex;
  }
{% endif %}