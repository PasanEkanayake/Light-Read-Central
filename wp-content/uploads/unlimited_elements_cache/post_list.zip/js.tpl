jQuery(document).ready(function(){	
function {{uc_id}}_start(){
  
   var objList = jQuery("#{{uc_id}}");
  
   var objRemoteOptions = {
    	class_items:"uc_post_list_box",
    	class_active:"ue-active-item",
      	add_set_active_code:true
    };
  
  	{{ucfunc("put_remote_parent_js","objList","objRemoteOptions")}}      
    	
}setTimeout(function(){if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});},100);
});